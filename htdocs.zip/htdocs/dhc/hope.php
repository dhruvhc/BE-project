<html>
<head>
    <title>lets go</title>
    
</head>
<body>
    <?php
   
    shell_exec('python connecttest.py')
        
        ?>
    </body>

</html>