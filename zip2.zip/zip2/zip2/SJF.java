import java.io.*;
import java.util.*;

class SJF
{
	public static void main(String args[])throws IOException
	{
		Scanner obj=new Scanner(System.in);
		int nop,i,j;
		float avgwt=0,avgtt=0;
		int process[]=new int[10];
		int burst_time[]=new int[10];
		int arrival_time[]=new int[10];
		int wait_time[]=new int[10];
		int tt_time[]=new int[10];
	
		System.out.println("Enter Number of processes:: ");
		nop=obj.nextInt();

		System.out.println("Enter processes:: ");
		for(i=0;i<nop;i++)
		{
			j=i+1;
			System.out.println("Enter process "+j);
			process[i]=obj.nextInt();
		}

		System.out.println("Enter Burst time for processes:: ");
		for(i=0;i<nop;i++)
		{
			j=i+1;
			System.out.println("Enter Burst time for process "+j);
			burst_time[i]=obj.nextInt();
		}

		System.out.println("Enter Arrival time for processes:: ");
		for(i=0;i<nop;i++)
		{
			j=i+1;
			System.out.println("Enter arrival time for process "+j);
			arrival_time[i]=obj.nextInt();
		}

		System.out.println("  Processes\tBurst Time\tArrival_Time");
		System.out.println("========================================================");
		for(i=0;i<nop;i++)
		{
			j=i+1;
			System.out.println(" "+process[i]+"\t\t"+burst_time[i]+"\t\t"+arrival_time[i]);
		}		
		

	
		int n=nop;
		int cmplt=0,minm=Integer.MAX_VALUE,shortest=0,t=0,finish_time;
		boolean check=false;
		int rt[]=new int[10];

		for(i=0;i<n;i++)
		{
			rt[i]=burst_time[i];
		}

		while(cmplt!=n)
		{
			for(j=0;j<n;j++)
			{
				if((arrival_time[j]<=t) && (rt[j]<minm) && (rt[j]>0) )
				{
					minm=rt[j];
					shortest=j;
					check=true;
			
				}
			}
			if(check==false)
			{
				t++;
				continue;
			}

			rt[shortest]--;
			minm=rt[shortest];

			if(minm==0)
			{
				minm=Integer.MAX_VALUE;
			}

			if(rt[shortest]==0)
			{
				cmplt++;
				check=false;
				finish_time=t+1;
		
				wait_time[shortest]=finish_time-burst_time[shortest]-arrival_time[shortest];

				if(wait_time[shortest] < 0)
					wait_time[shortest]=0;
			}
			t++;
		}

		//turn around time
		for(i=0;i<nop;i++)
		{
			tt_time[i]=burst_time[i]+wait_time[i];
		}

		System.out.println("  Processes\tBurst Time\tArrival_Time\twaiting time\tturn around time");
		System.out.println("=======================================================================================");
		for(i=0;i<nop;i++)
		{
			System.out.println(" "+process[i]+"\t\t"+burst_time[i]+"\t\t"+arrival_time[i]+"\t\t"+wait_time[i]+"\t\t"+tt_time[i]);
		}				

		for(i=0;i<nop;i++)
		{
			avgwt=wait_time[i]+avgwt;
		}
		System.out.println("Average waiting time: "+avgwt/nop);

		for(i=0;i<nop;i++)
		{
			avgtt=tt_time[i]+avgtt;
		}
		System.out.println("Average turn around time: "+avgtt/nop);
		






	}
}
