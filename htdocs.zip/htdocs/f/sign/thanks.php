
<?php 
include('csvinphp.php');
header("Refresh:7; url=../index.html");
echo 'Thank You for using our service..';
 echo 'You\'ll be redirected in about 5 secs. If not, click <a href="../index.html">here</a>.';
?>